# 한동대 AWS 캠프 

* DATE: 2019/07/10 ~ 12

## [Day-1] 
[AWS Web Application](./Day-1.md)

## [Day-2] 
[Build a Serverless Web Application](./Day-2.md)

## [Day-3]
[BIG DATA Practices](./Day-3-1.md)</br>
[AI/ML Practices](./Day-3-2.md)
