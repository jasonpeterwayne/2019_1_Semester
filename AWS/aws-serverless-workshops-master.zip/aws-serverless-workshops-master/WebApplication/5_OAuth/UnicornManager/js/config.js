window._config = {
    cognito: {
        userPoolClientId: 'COGNITO APPLICATION ID', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'AWS REGION', // e.g. us-east-2
        authDomainPrefix: 'CONFIGURED COGNITO DOMAIN PREFIX' // wildrydes-sapessi
    },
    api: {
        invokeUrl: 'API ENDPOINT URI' // e.g. https://xxxxxxxx.execute-api.us-west-2.amazonaws.com/prod',
    }
};
