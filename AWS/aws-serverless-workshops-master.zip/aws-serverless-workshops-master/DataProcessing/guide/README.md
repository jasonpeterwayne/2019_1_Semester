# Serverless Data Processing on AWS

## Development

### Building content on file changes

- docker build -t guide .
- docker run -ti -v $PWD:/guide guide
